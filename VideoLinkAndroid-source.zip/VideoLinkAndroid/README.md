# Vídeo Direto para Android

Aplicativo Android simples para salvar arquivos de vídeo a partir de links diretos autorizados. O projeto foi preparado para rodar em Android 8.0 ou superior, incluindo o Samsung Galaxy A54.

## O que o app faz

- Recebe um endereço `http://` ou `https://` de um arquivo de vídeo.
- Abre o seletor de documentos do Android para você escolher a pasta e o nome do arquivo.
- Mostra o progresso do download e salva o arquivo escolhido.
- Rejeita endereços do YouTube e redirecionamentos para domínios do YouTube.

O endereço precisa entregar o arquivo de vídeo diretamente. Páginas de vídeo, playlists, links que exigem login e links do YouTube não são baixados. Use somente arquivos que você tem autorização para salvar.

## Gerar o APK pelo GitHub

1. Crie um repositório no GitHub e envie para ele o conteúdo desta pasta, mantendo `.github/workflows/android.yml` no mesmo caminho.
2. Abra a aba **Actions** do repositório. A compilação também começa automaticamente quando você enviar uma alteração para a branch `main` ou `master`.
3. Abra a execução concluída e baixe o artefato **video-direto-debug-apk**. Dentro dele estará `app-debug.apk`.
4. No Galaxy A54, transfira o APK e abra-o para instalar. O Android pode pedir que você autorize a instalação de aplicativos dessa fonte.

Você também pode iniciar a compilação manualmente em **Actions → Build Android APK → Run workflow**.

## Compilar localmente

Abra a pasta no Android Studio e aguarde a sincronização do Gradle. Para compilar pela linha de comando com Gradle 8.13 e JDK 17:

```text
gradle assembleDebug
```

O APK de depuração será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Downloads do YouTube

Este aplicativo não extrai nem baixa vídeos do YouTube. Para assistir offline, use os recursos disponíveis no aplicativo YouTube. Para baixar um vídeo que você enviou, use o YouTube Studio ou o Google Takeout: [ajuda oficial do YouTube](https://support.google.com/youtube/answer/56100?hl=pt-BR).
