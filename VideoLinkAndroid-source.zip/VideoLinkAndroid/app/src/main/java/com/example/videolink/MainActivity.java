package com.example.videolink;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int CREATE_FILE_REQUEST = 41;
    private static final int BLUE = 0xFF2563EB;
    private static final int INK = 0xFF152238;
    private static final int MUTED = 0xFF64748B;
    private static final int PAGE = 0xFFF5F7FB;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText urlField;
    private Button downloadButton;
    private ProgressBar progressBar;
    private TextView statusText;
    private Uri sourceUri;
    private String suggestedName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(PAGE);
        getWindow().setNavigationBarColor(PAGE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        setContentView(createPage());
    }

    private View createPage() {
        ScrollView page = new ScrollView(this);
        page.setFillViewport(true);
        page.setBackgroundColor(PAGE);
        page.setOnApplyWindowInsetsListener((view, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(dp(22), top + dp(12), dp(22), bottom + dp(18));
            return insets;
        });

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        page.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        TextView badge = text("DOWNLOADS AUTORIZADOS", 12, BLUE, true);
        badge.setLetterSpacing(0.08f);
        badge.setPadding(0, dp(12), 0, dp(10));
        content.addView(badge);

        TextView title = text("Vídeo\nDireto", 34, INK, true);
        title.setLineSpacing(dp(1), 1f);
        content.addView(title);

        TextView intro = text(
                "Salve no aparelho um arquivo de vídeo a partir de um link direto.",
                16, MUTED, false);
        intro.setPadding(0, dp(12), 0, dp(24));
        content.addView(intro);

        TextView urlLabel = text("Link do arquivo", 14, INK, true);
        content.addView(urlLabel);

        urlField = new EditText(this);
        urlField.setSingleLine(true);
        urlField.setHint("https://site.com/video.mp4");
        urlField.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlField.setTextSize(15);
        urlField.setPadding(dp(14), dp(13), dp(14), dp(13));
        urlField.setBackground(roundRect(0xFFFFFFFF, dp(14), 0xFFD9E1EE, dp(1)));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        inputParams.topMargin = dp(8);
        content.addView(urlField, inputParams);

        downloadButton = new Button(this);
        downloadButton.setText("Escolher pasta e baixar");
        downloadButton.setTextColor(0xFFFFFFFF);
        downloadButton.setTextSize(15);
        downloadButton.setAllCaps(false);
        downloadButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        downloadButton.setBackground(roundRect(BLUE, dp(14), BLUE, 0));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        buttonParams.topMargin = dp(16);
        content.addView(downloadButton, buttonParams);
        downloadButton.setOnClickListener(view -> chooseDestination());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(5));
        progressParams.topMargin = dp(20);
        content.addView(progressBar, progressParams);

        statusText = text("", 14, MUTED, false);
        statusText.setPadding(0, dp(10), 0, dp(4));
        content.addView(statusText);

        TextView infoTitle = text("Como funciona", 17, INK, true);
        infoTitle.setPadding(0, dp(28), 0, dp(8));
        content.addView(infoTitle);

        TextView info = text(
                "Cole o endereço direto de um arquivo de vídeo, escolha onde salvá-lo e acompanhe o progresso aqui. "
                        + "O link precisa abrir o arquivo de vídeo; páginas de sites e playlists não são baixadas.",
                14, MUTED, false);
        info.setLineSpacing(dp(4), 1f);
        content.addView(info);

        TextView note = text(
                "Use apenas conteúdo que você tem autorização para salvar. Links do YouTube não são aceitos.",
                13, 0xFF475569, false);
        note.setPadding(dp(14), dp(14), dp(14), dp(14));
        note.setBackground(roundRect(0xFFEAF0FA, dp(12), 0xFFEAF0FA, 0));
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        noteParams.topMargin = dp(20);
        content.addView(note, noteParams);

        return page;
    }

    private void chooseDestination() {
        String raw = urlField.getText().toString().trim();
        Uri parsed = Uri.parse(raw);
        String scheme = parsed.getScheme();
        String host = parsed.getHost();
        if ((scheme == null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http")))
                || host == null || host.isEmpty()) {
            showStatus("Informe um link direto que comece com http:// ou https://.", true);
            return;
        }
        if (isYouTubeHost(host)) {
            showStatus("Links do YouTube não são aceitos. Use os recursos oficiais do YouTube.", true);
            return;
        }

        sourceUri = parsed;
        suggestedName = makeFileName(parsed);
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.putExtra(Intent.EXTRA_TITLE, suggestedName);
        intent.putExtra("android.content.extra.SHOW_ADVANCED", true);
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_FILE_REQUEST || resultCode != RESULT_OK || data == null) return;
        Uri destination = data.getData();
        if (destination == null || sourceUri == null) return;
        beginDownload(sourceUri, destination);
    }

    private void beginDownload(Uri from, Uri to) {
        downloadButton.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        progressBar.setProgress(0);
        showStatus("Conectando ao servidor…", false);

        executor.execute(() -> {
            HttpURLConnection connection = null;
            boolean outputOpened = false;
            try {
                URL requestUrl = new URL(from.toString());
                connection = (HttpURLConnection) requestUrl.openConnection();
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(30000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("Accept", "video/*, application/octet-stream;q=0.9, */*;q=0.8");
                connection.setRequestProperty("User-Agent", "VideoDireto/1.0 (Android)");
                connection.connect();

                int response = connection.getResponseCode();
                if (response < 200 || response >= 300) {
                    throw new IllegalStateException("O servidor respondeu com HTTP " + response + ".");
                }
                if (isYouTubeHost(connection.getURL().getHost())) {
                    throw new IllegalStateException("Este link redireciona para o YouTube e foi bloqueado.");
                }

                String contentType = connection.getContentType();
                if (!isVideoResponse(contentType)) {
                    throw new IllegalStateException(
                            "O endereço não respondeu com um arquivo de vídeo. Cole o link direto do arquivo.");
                }

                long totalBytes = connection.getContentLengthLong();
                postProgress(totalBytes, 0);
                try (InputStream input = new BufferedInputStream(connection.getInputStream());
                     OutputStream output = getContentResolver().openOutputStream(to, "w")) {
                    if (output == null) throw new IllegalStateException("Não foi possível abrir o arquivo de destino.");
                    outputOpened = true;
                    byte[] buffer = new byte[64 * 1024];
                    long downloaded = 0;
                    int count;
                    while ((count = input.read(buffer)) != -1) {
                        output.write(buffer, 0, count);
                        downloaded += count;
                        postProgress(totalBytes, downloaded);
                    }
                    output.flush();
                }
                mainHandler.post(() -> {
                    progressBar.setIndeterminate(false);
                    progressBar.setProgress(100);
                    showStatus("Download concluído: " + suggestedName, false);
                    downloadButton.setEnabled(true);
                });
            } catch (Exception exception) {
                if (outputOpened) {
                    try {
                        getContentResolver().delete(to, null, null);
                    } catch (Exception ignored) {
                        // Some document providers do not allow deleting a partial file.
                    }
                }
                String message = exception.getMessage();
                if (message == null || message.trim().isEmpty()) message = "Não foi possível concluir o download.";
                final String error = message;
                mainHandler.post(() -> {
                    progressBar.setVisibility(View.GONE);
                    showStatus(error, true);
                    downloadButton.setEnabled(true);
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private void postProgress(long total, long downloaded) {
        mainHandler.post(() -> {
            if (total > 0) {
                progressBar.setIndeterminate(false);
                int percent = (int) Math.min(100, downloaded * 100L / total);
                progressBar.setProgress(percent);
                showStatus(String.format(Locale.getDefault(), "Baixando… %d%%", percent), false);
            } else {
                progressBar.setIndeterminate(true);
                showStatus("Baixando… " + formatSize(downloaded), false);
            }
        });
    }

    private boolean isVideoResponse(String contentType) {
        if (contentType == null) return false;
        String type = contentType.toLowerCase(Locale.ROOT);
        return type.startsWith("video/") || type.contains("application/octet-stream")
                || type.contains("application/mp4") || type.contains("application/x-matroska");
    }

    private boolean isYouTubeHost(String host) {
        String value = host.toLowerCase(Locale.ROOT);
        return value.equals("youtube.com") || value.endsWith(".youtube.com")
                || value.equals("youtu.be") || value.endsWith(".youtu.be")
                || value.equals("youtube-nocookie.com") || value.endsWith(".youtube-nocookie.com")
                || value.equals("googlevideo.com") || value.endsWith(".googlevideo.com");
    }

    private String makeFileName(Uri uri) {
        String name = uri.getLastPathSegment();
        if (name != null) name = Uri.decode(name);
        if (name == null || name.trim().isEmpty()) name = "video.mp4";
        name = name.replaceAll("[^\\p{L}\\p{N}._ -]", "_").trim();
        if (name.isEmpty() || name.equals(".") || name.equals("..")) name = "video.mp4";
        if (!name.contains(".")) name += ".mp4";
        if (name.length() > 100) {
            int dot = name.lastIndexOf('.');
            String extension = dot > 0 && name.length() - dot <= 8 ? name.substring(dot) : ".mp4";
            name = name.substring(0, Math.min(90, name.length())) + extension;
        }
        return name;
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
    }

    private void showStatus(String message, boolean error) {
        statusText.setText(message);
        statusText.setTextColor(error ? 0xFFB42318 : MUTED);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private android.graphics.drawable.GradientDrawable roundRect(int fill, int radius, int stroke, int strokeWidth) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        if (strokeWidth > 0) drawable.setStroke(strokeWidth, stroke);
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
